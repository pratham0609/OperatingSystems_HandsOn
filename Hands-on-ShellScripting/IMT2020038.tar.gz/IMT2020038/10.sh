#!/bin/bash

tar -cvzf "$2.tar.gz" $1

