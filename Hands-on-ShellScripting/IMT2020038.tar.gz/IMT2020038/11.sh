#!/bin/bash

du -h /"$1"

