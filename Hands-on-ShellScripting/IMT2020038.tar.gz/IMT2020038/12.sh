#! /bin/bash

read i

case $i in

     	IIT)
        	 echo "NIT"
		 ;;
         	
     	NIT)
        	 echo "IIT"
         	 ;;
     	*)
      		 echo "STDERR"
       		 ;;
esac
~            
